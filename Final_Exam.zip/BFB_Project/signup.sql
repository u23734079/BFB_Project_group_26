-- =====================================================
-- SMART WASH DATABASE SCHEMA
-- Execute this entire file with Shift + Ctrl + Q in VS Code
-- =====================================================

-- Enable foreign key constraints
PRAGMA foreign_keys = ON;

-- =====================================================
-- DROP EXISTING TABLES (Clean slate)
-- =====================================================

DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS tracklaundry;
DROP TABLE IF EXISTS slot;
DROP TABLE IF EXISTS dayofmonth;
DROP TABLE IF EXISTS timeseek;
DROP TABLE IF EXISTS services;
DROP TABLE IF EXISTS service_categories;
DROP TABLE IF EXISTS queries;
DROP TABLE IF EXISTS signup;

-- =====================================================
-- CUSTOMER MANAGEMENT TABLES
-- =====================================================

-- Main signup/customer table
CREATE TABLE signup (
    Customer_id INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    cell_number TEXT NOT NULL UNIQUE,
    residential_address TEXT NOT NULL,
    password TEXT NOT NULL,
    status VARCHAR(20) DEFAULT 'Active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Customer queries/support tickets
CREATE TABLE queries (
    query_id INTEGER PRIMARY KEY AUTOINCREMENT,
    Customer_id INTEGER NOT NULL,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL,
    cell_number TEXT NOT NULL,
    problem_description TEXT NOT NULL,
    details TEXT NOT NULL,
    status VARCHAR(20) DEFAULT 'Pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    resolved_at DATETIME,
    FOREIGN KEY (Customer_id) REFERENCES signup(Customer_id) ON DELETE CASCADE
);

-- =====================================================
-- SERVICE CATEGORIES AND PRICING
-- =====================================================

-- Service categories (similar to product_categories)
CREATE TABLE service_categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category_code VARCHAR(20) UNIQUE NOT NULL,
    category_name VARCHAR(100) NOT NULL,
    description TEXT,
    status VARCHAR(20) DEFAULT 'Active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Services/Products offered
CREATE TABLE services (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    service_code VARCHAR(50) UNIQUE NOT NULL,
    service_name VARCHAR(200) NOT NULL,
    description TEXT,
    category_id INTEGER,
    unit_price DECIMAL(10,2) NOT NULL,
    duration_minutes INTEGER DEFAULT 60,
    status VARCHAR(20) DEFAULT 'Active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES service_categories(id)
);

-- =====================================================
-- BOOKING SYSTEM TABLES
-- =====================================================

-- Available time slots
CREATE TABLE timeseek (
    time TEXT PRIMARY KEY NOT NULL,
    status VARCHAR(20) DEFAULT 'Active'
);

-- Available days
CREATE TABLE dayofmonth (
    day INTEGER PRIMARY KEY NOT NULL,
    status VARCHAR(20) DEFAULT 'Active'
);

-- Customer bookings/slots
CREATE TABLE slot (
    slot_id INTEGER PRIMARY KEY AUTOINCREMENT,
    Customer_id INTEGER NOT NULL,
    service_id INTEGER,
    day INTEGER NOT NULL,
    time TEXT NOT NULL,
    status VARCHAR(20) DEFAULT 'Booked',
    booking_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (Customer_id) REFERENCES signup(Customer_id) ON DELETE CASCADE,
    FOREIGN KEY (service_id) REFERENCES services(id),
    FOREIGN KEY (day) REFERENCES dayofmonth(day),
    FOREIGN KEY (time) REFERENCES timeseek(time)
);

-- =====================================================
-- LAUNDRY TRACKING SYSTEM
-- =====================================================

-- Laundry status tracking
CREATE TABLE tracklaundry (
    laundry_id INTEGER PRIMARY KEY AUTOINCREMENT,
    Customer_id INTEGER NOT NULL,
    slot_id INTEGER,
    status VARCHAR(50) DEFAULT 'Received',
    weight_kg DECIMAL(5,2),
    special_instructions TEXT,
    received_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    wash_start_date DATETIME,
    wash_complete_date DATETIME,
    ready_for_pickup_date DATETIME,
    delivered_date DATETIME,
    total_amount DECIMAL(10,2),
    FOREIGN KEY (Customer_id) REFERENCES signup(Customer_id) ON DELETE CASCADE,
    FOREIGN KEY (slot_id) REFERENCES slot(slot_id)
);

-- =====================================================
-- PAYMENT AND ORDERS
-- =====================================================

-- Customer orders
CREATE TABLE orders (
    order_id INTEGER PRIMARY KEY AUTOINCREMENT,
    Customer_id INTEGER NOT NULL,
    laundry_id INTEGER,
    order_number VARCHAR(50) UNIQUE NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    payment_status VARCHAR(20) DEFAULT 'Pending',
    order_status VARCHAR(20) DEFAULT 'Processing',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (Customer_id) REFERENCES signup(Customer_id) ON DELETE CASCADE,
    FOREIGN KEY (laundry_id) REFERENCES tracklaundry(laundry_id)
);

-- Order line items
CREATE TABLE order_items (
    item_id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL,
    service_id INTEGER NOT NULL,
    quantity INTEGER DEFAULT 1,
    unit_price DECIMAL(10,2) NOT NULL,
    total_price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (service_id) REFERENCES services(id)
);

-- =====================================================
-- SAMPLE DATA INSERTION
-- =====================================================

-- Insert service categories
INSERT INTO service_categories (category_code, category_name, description) VALUES
('WASH-STD', 'Standard Wash', 'Regular washing and drying services'),
('WASH-PRM', 'Premium Wash', 'Premium washing with fabric softener and special care'),
('DRY-CLN', 'Dry Cleaning', 'Professional dry cleaning services'),
('IRON-SVC', 'Ironing Service', 'Professional ironing and pressing'),
('SPEC-SVC', 'Special Services', 'Special treatment for delicate items');

-- Insert services
INSERT INTO services (service_code, service_name, description, category_id, unit_price, duration_minutes) VALUES
('WS-001', 'Standard Wash (per kg)', 'Regular machine wash and dry', 1, 25.00, 120),
('WS-002', 'Premium Wash (per kg)', 'Premium wash with fabric softener', 2, 35.00, 150),
('DC-001', 'Dry Clean - Shirt', 'Dry cleaning for shirts', 3, 45.00, 180),
('DC-002', 'Dry Clean - Pants', 'Dry cleaning for pants', 3, 50.00, 180),
('DC-003', 'Dry Clean - Suit', 'Complete suit dry cleaning', 3, 120.00, 240),
('IR-001', 'Iron - per item', 'Professional ironing service', 4, 15.00, 30),
('SP-001', 'Bedding Service', 'Washing for bedding and linens', 5, 80.00, 180);

-- Insert time slots
INSERT INTO timeseek (time) VALUES
('08:00 - 10:00'),
('10:00 - 12:00'),
('12:00 - 14:00'),
('14:00 - 16:00'),
('16:00 - 18:00');

-- Insert sample days (just the day number, simplified)
INSERT INTO dayofmonth (day) VALUES
(25), (26), (27), (28), (29), (30),
(1), (2), (3), (4), (5), (6), (7), (8), (9), (10),
(11), (12), (13), (14), (15), (16), (17), (18), (19), (20),
(21), (22), (23), (24);

-- =====================================================
-- INDEXES FOR PERFORMANCE
-- =====================================================

CREATE INDEX idx_signup_email ON signup(email);
CREATE INDEX idx_signup_status ON signup(status);
CREATE INDEX idx_slot_customer ON slot(Customer_id);
CREATE INDEX idx_slot_status ON slot(status);
CREATE INDEX idx_laundry_customer ON tracklaundry(Customer_id);
CREATE INDEX idx_laundry_status ON tracklaundry(status);
CREATE INDEX idx_orders_customer ON orders(Customer_id);
CREATE INDEX idx_orders_status ON orders(order_status);

-- =====================================================
-- VERIFY TABLES CREATED
-- =====================================================

-- View all tables to confirm
SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;