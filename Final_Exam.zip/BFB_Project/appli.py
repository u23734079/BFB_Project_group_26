from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import secrets

app = Flask(__name__)
app.secret_key = secrets.token_hex(32)  # Secure random secret key

# Database helper functions
def get_db_connection():
    """Create and return a database connection with row factory"""
    con = sqlite3.connect('signup.db')
    con.row_factory = sqlite3.Row
    return con

def init_db():
    """Initialize database with schema if needed"""
    with app.app_context():
        con = get_db_connection()
        con.close()

# Decorators
def login_required(f):
    """Decorator to require login for certain routes"""
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please login to access this page.', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# =====================================================
# PUBLIC ROUTES (NOT LOGGED IN)
# =====================================================

@app.route('/')
def home():
    """Home page route - shows home.html if not logged in"""
    if 'user_id' in session:
        return redirect(url_for('home1'))
    return render_template('home.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    """User registration route"""
    if request.method == 'POST':
        # Get form data
        full_name = request.form.get('fullname', '').strip()
        email = request.form.get('email', '').strip().lower()
        cell_number = request.form.get('cell', '').strip()
        residential_address = request.form.get('address', '').strip()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm', '')
        
        # Validation
        if not all([full_name, email, cell_number, residential_address, password, confirm_password]):
            flash('All fields are required!', 'error')
            return render_template('signup.html')
        
        if len(password) < 8:
            flash('Password must be at least 8 characters long!', 'error')
            return render_template('signup.html')
        
        if password != confirm_password:
            flash('Passwords do not match!', 'error')
            return render_template('signup.html')
        
        # Validate email format
        if '@' not in email or '.' not in email:
            flash('Please enter a valid email address!', 'error')
            return render_template('signup.html')
        
        # Validate cell number (basic validation)
        if not cell_number.isdigit() or len(cell_number) < 10:
            flash('Please enter a valid cell number!', 'error')
            return render_template('signup.html')
        
        con = get_db_connection()
        cur = con.cursor()
        
        try:
            # Check if user already exists
            existing_user = cur.execute(
                'SELECT * FROM signup WHERE email = ? OR cell_number = ?',
                (email, cell_number)
            ).fetchone()
            
            if existing_user:
                flash('Email or cell number already registered!', 'error')
                return render_template('signup.html')
            
            # Hash password for security
            hashed_password = generate_password_hash(password)
            
            # Insert new user with timestamp
            cur.execute('''
                INSERT INTO signup (full_name, email, cell_number, residential_address, password, status, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, 'Active', ?, ?)
            ''', (full_name, email, cell_number, residential_address, hashed_password, 
                  datetime.now(), datetime.now()))
            con.commit()
            
            flash('Account created successfully! Please login.', 'success')
            return redirect(url_for('login'))
            
        except sqlite3.IntegrityError as e:
            flash(f'An error occurred: {str(e)}', 'error')
            return render_template('signup.html')
        except Exception as e:
            flash('An unexpected error occurred. Please try again.', 'error')
            return render_template('signup.html')
        finally:
            con.close()
    
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """User login route"""
    if request.method == 'POST':
        email = request.form.get('username', '').strip().lower()
        password = request.form.get('password', '')
        
        if not email or not password:
            flash('Please enter both email and password!', 'error')
            return render_template('login.html')
        
        con = get_db_connection()
        cur = con.cursor()
        
        try:
            # Check credentials
            user = cur.execute(
                'SELECT * FROM signup WHERE email = ? AND status = ?',
                (email, 'Active')
            ).fetchone()
            
            # Verify password hash
            if user and check_password_hash(user['password'], password):
                # Store user info in session
                session['user_id'] = user['Customer_id']
                session['user_name'] = user['full_name']
                session['user_email'] = user['email']
                session['logged_in'] = True
                
                # Update last login timestamp
                cur.execute(
                    'UPDATE signup SET updated_at = ? WHERE Customer_id = ?',
                    (datetime.now(), user['Customer_id'])
                )
                con.commit()
                
                flash(f'Welcome back, {user["full_name"]}!', 'success')
                return redirect(url_for('dashboard'))
            else:
                flash('Invalid email or password. Please try again.', 'error')
                return render_template('login.html')
                
        except Exception as e:
            flash('An error occurred during login. Please try again.', 'error')
            return render_template('login.html')
        finally:
            con.close()
    
    return render_template('login.html')

@app.route('/contact', methods=['GET', 'POST'])
def contact_us():
    """Contact us page for non-logged in users"""
    if request.method == 'POST':
        full_name = request.form.get('fullname', '').strip()
        email = request.form.get('email', '').strip().lower()
        cell_number = request.form.get('cell', '').strip()
        description = request.form.get('description', '').strip()
        details = request.form.get('details', '').strip()
        
        if not all([full_name, email, cell_number, description, details]):
            flash('All fields are required!', 'error')
            return render_template('contact_us.html')
        
        con = get_db_connection()
        cur = con.cursor()
        
        try:
            # Get customer_id if user is logged in, otherwise use 0
            customer_id = session.get('user_id', 0)
            
            cur.execute('''
                INSERT INTO queries (Customer_id, full_name, email, cell_number, 
                                   problem_description, details, status, created_at)
                VALUES (?, ?, ?, ?, ?, ?, 'Pending', ?)
            ''', (customer_id, full_name, email, cell_number, description, details, datetime.now()))
            con.commit()
            
            flash('Your query has been submitted successfully! We will contact you soon.', 'success')
            return redirect(url_for('contact_us'))
        except Exception as e:
            flash('An error occurred. Please try again.', 'error')
            return render_template('contact_us.html')
        finally:
            con.close()
    
    return render_template('contact_us.html')

@app.route('/privacy-policy')
def privacy_policy():
    """Privacy policy page for non-logged in users"""
    if 'user_id' in session:
        return redirect(url_for('privacy_policy1'))
    return render_template('privacy_policy.html')

# =====================================================
# PROTECTED ROUTES (LOGGED IN USERS ONLY)
# =====================================================

@app.route('/home1')
@login_required
def home1():
    """Home page for logged-in users"""
    return render_template('home1.html', user_name=session.get('user_name'))

@app.route('/dashboard')
@login_required
def dashboard():
    """User dashboard showing bookings and laundry status"""
    con = get_db_connection()
    cur = con.cursor()
    
    try:
        # Get user's slots with service information
        slots = cur.execute('''
            SELECT s.slot_id, s.day, s.time, s.status, s.booking_date,
                   sv.service_name, sv.unit_price
            FROM slot s
            LEFT JOIN services sv ON s.service_id = sv.id
            WHERE s.Customer_id = ?
            ORDER BY s.day, s.time
        ''', (session['user_id'],)).fetchall()
        
        # Get user's laundry tracking with detailed information
        laundry = cur.execute('''
            SELECT t.laundry_id, t.status, t.weight_kg, t.total_amount,
                   t.received_date, t.ready_for_pickup_date, t.special_instructions
            FROM tracklaundry t
            WHERE t.Customer_id = ?
            ORDER BY t.received_date DESC
        ''', (session['user_id'],)).fetchall()
        
        # Get user's recent orders
        orders = cur.execute('''
            SELECT o.order_id, o.order_number, o.total_amount, 
                   o.payment_status, o.order_status, o.created_at
            FROM orders o
            WHERE o.Customer_id = ?
            ORDER BY o.created_at DESC
            LIMIT 5
        ''', (session['user_id'],)).fetchall()
        
        # Get available services for booking
        services = cur.execute('''
            SELECT id, service_code, service_name, description, unit_price, duration_minutes
            FROM services
            WHERE status = 'Active'
            ORDER BY service_name
        ''').fetchall()
        
        return render_template('dashboard.html', 
                             user_name=session['user_name'],
                             slots=slots,
                             laundry=laundry,
                             orders=orders,
                             services=services)
    except Exception as e:
        flash('Error loading dashboard data.', 'error')
        return render_template('dashboard.html', 
                             user_name=session['user_name'],
                             slots=[], laundry=[], orders=[], services=[])
    finally:
        con.close()

@app.route('/contact1', methods=['GET', 'POST'])
@login_required
def contact_us1():
    """Contact us page for logged-in users"""
    if request.method == 'POST':
        full_name = request.form.get('fullname', '').strip()
        email = request.form.get('email', '').strip().lower()
        cell_number = request.form.get('cell', '').strip()
        description = request.form.get('description', '').strip()
        details = request.form.get('details', '').strip()
        
        if not all([full_name, email, cell_number, description, details]):
            flash('All fields are required!', 'error')
            return render_template('contact_us1.html')
        
        con = get_db_connection()
        cur = con.cursor()
        
        try:
            customer_id = session.get('user_id')
            
            cur.execute('''
                INSERT INTO queries (Customer_id, full_name, email, cell_number, 
                                   problem_description, details, status, created_at)
                VALUES (?, ?, ?, ?, ?, ?, 'Pending', ?)
            ''', (customer_id, full_name, email, cell_number, description, details, datetime.now()))
            con.commit()
            
            flash('Your query has been submitted successfully! We will contact you soon.', 'success')
            return redirect(url_for('contact_us1'))
        except Exception as e:
            flash('An error occurred. Please try again.', 'error')
            return render_template('contact_us1.html')
        finally:
            con.close()
    
    return render_template('contact_us1.html', user_name=session.get('user_name'))

@app.route('/privacy-policy1')
@login_required
def privacy_policy1():
    """Privacy policy page for logged-in users"""
    return render_template('privacy_policy1.html', user_name=session.get('user_name'))

@app.route('/product')
@login_required
def product():
    """Product/Service tracking page for customers"""
    con = get_db_connection()
    cur = con.cursor()
    
    try:
        # Get user's latest laundry tracking info
        laundry = cur.execute('''
            SELECT t.laundry_id, t.status, t.weight_kg, t.total_amount,
                   t.received_date, t.wash_start_date, t.wash_complete_date,
                   t.ready_for_pickup_date, t.delivered_date, t.special_instructions
            FROM tracklaundry t
            WHERE t.Customer_id = ?
            ORDER BY t.received_date DESC
            LIMIT 1
        ''', (session['user_id'],)).fetchone()
        
        return render_template('product.html', 
                             user_name=session.get('user_name'),
                             laundry=laundry)
    except Exception as e:
        flash('Error loading laundry status.', 'error')
        return render_template('product.html', 
                             user_name=session.get('user_name'),
                             laundry=None)
    finally:
        con.close()

@app.route('/product-admin', methods=['GET', 'POST'])
@login_required
def product_admin():
    """Admin page for managing laundry orders"""
    # You can add admin check here later
    
    if request.method == 'POST':
        laundry_id = request.form.get('laundry_id')
        laundry_load = request.form.get('laundryLoad')
        laundry_status = request.form.get('laundryStatus')
        delivery_status = request.form.get('deliveryStatus')
        
        con = get_db_connection()
        cur = con.cursor()
        
        try:
            # Update laundry tracking
            cur.execute('''
                UPDATE tracklaundry 
                SET status = ?, weight_kg = ?, updated_at = ?
                WHERE laundry_id = ?
            ''', (laundry_status, laundry_load, datetime.now(), laundry_id))
            con.commit()
            
            flash('Laundry status updated successfully!', 'success')
        except Exception as e:
            flash('Error updating status.', 'error')
        finally:
            con.close()
        
        return redirect(url_for('product_admin'))
    
    # Get all active laundry orders
    con = get_db_connection()
    cur = con.cursor()
    
    try:
        laundry_orders = cur.execute('''
            SELECT t.laundry_id, t.Customer_id, t.status, t.weight_kg,
                   t.received_date, s.full_name, s.email, s.cell_number
            FROM tracklaundry t
            JOIN signup s ON t.Customer_id = s.Customer_id
            WHERE t.status NOT IN ('Delivered', 'Completed')
            ORDER BY t.received_date DESC
        ''').fetchall()
        
        return render_template('product-admin.html', 
                             user_name=session.get('user_name'),
                             laundry_orders=laundry_orders)
    except Exception as e:
        flash('Error loading laundry orders.', 'error')
        return render_template('product-admin.html', 
                             user_name=session.get('user_name'),
                             laundry_orders=[])
    finally:
        con.close()

@app.route('/pickup', methods=['GET', 'POST'])
@login_required
def pickup():
    """Pickup address page"""
    if request.method == 'POST':
        address = request.form.get('address', '').strip()
        
        if not address:
            flash('Please enter a pickup address!', 'error')
            return render_template('pickup.html', user_name=session.get('user_name'))
        
        con = get_db_connection()
        cur = con.cursor()
        
        try:
            # Update user's residential address or store pickup address
            cur.execute('''
                UPDATE signup 
                SET residential_address = ?, updated_at = ?
                WHERE Customer_id = ?
            ''', (address, datetime.now(), session['user_id']))
            
            # Create a new laundry tracking entry for the customer
            cur.execute('''
                INSERT INTO tracklaundry (Customer_id, status, received_date)
                VALUES (?, 'Finding a driver', ?)
            ''', (session['user_id'], datetime.now()))
            
            con.commit()
            
            flash('Pickup address confirmed!', 'success')
            return redirect(url_for('confirm'))
        except Exception as e:
            flash('Error saving address.', 'error')
            return render_template('pickup.html', user_name=session.get('user_name'))
        finally:
            con.close()
    
    return render_template('pickup.html', user_name=session.get('user_name'))

@app.route('/confirm')
@login_required
def confirm():
    """Confirmation page after pickup address"""
    return render_template('confirm.html', user_name=session.get('user_name'))

@app.route('/logout')
def logout():
    """User logout route"""
    user_name = session.get('user_name', 'User')
    session.clear()
    flash(f'Goodbye, {user_name}! You have been logged out successfully.', 'success')
    return redirect(url_for('home'))

# =====================================================
# ADMIN ROUTES (Optional - Add admin check later)
# =====================================================

@app.route('/admin/users')
@login_required
def admin_users():
    """Admin page to view all users"""
    # Add authentication check for admin here
    con = get_db_connection()
    cur = con.cursor()
    
    try:
        all_users = cur.execute('''
            SELECT Customer_id, full_name, email, cell_number, 
                   residential_address, status, created_at
            FROM signup
            ORDER BY created_at DESC
        ''').fetchall()
        return render_template('users.html', users=all_users, user_name=session.get('user_name'))
    except Exception as e:
        flash('Error loading users.', 'error')
        return render_template('users.html', users=[], user_name=session.get('user_name'))
    finally:
        con.close()

@app.route('/admin/queries')
@login_required
def admin_queries():
    """Admin page to view all queries"""
    # Add authentication check for admin here
    con = get_db_connection()
    cur = con.cursor()
    
    try:
        all_queries = cur.execute('''
            SELECT q.*, s.full_name as customer_name
            FROM queries q
            LEFT JOIN signup s ON q.Customer_id = s.Customer_id
            ORDER BY q.created_at DESC
        ''').fetchall()
        return render_template('queries.html', queries=all_queries, user_name=session.get('user_name'))
    except Exception as e:
        flash('Error loading queries.', 'error')
        return render_template('queries.html', queries=[], user_name=session.get('user_name'))
    finally:
        con.close()

# =====================================================
# ERROR HANDLERS
# =====================================================

@app.errorhandler(404)
def page_not_found(e):
    """Handle 404 errors"""
    flash('Page not found. Redirecting to home.', 'error')
    if 'user_id' in session:
        return redirect(url_for('home1'))
    return redirect(url_for('home'))

@app.errorhandler(500)
def internal_server_error(e):
    """Handle 500 errors"""
    flash('An internal error occurred. Please try again.', 'error')
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('home'))

# =====================================================
# TEMPLATE FILTERS
# =====================================================

@app.template_filter('datetime')
def format_datetime(value, format='%Y-%m-%d %H:%M'):
    """Format datetime for template display"""
    if value is None:
        return ""
    if isinstance(value, str):
        try:
            value = datetime.fromisoformat(value)
        except:
            return value
    return value.strftime(format)

@app.template_filter('currency')
def format_currency(value):
    """Format currency for template display"""
    if value is None:
        return "R 0.00"
    return f"R {float(value):.2f}"

# =====================================================
# APPLICATION INITIALIZATION
# =====================================================

if __name__ == '__main__':
    init_db()
    app.run(debug=True, host='0.0.0.0', port=5000)