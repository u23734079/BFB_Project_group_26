import sqlite3
import os
from werkzeug.security import generate_password_hash

# Delete old corrupted database if it exists
if os.path.exists('signup1.db'):
    os.remove('signup1.db')
    print("✓ Removed old corrupted database")

# Create new database connection
con = sqlite3.connect('signup1.db')
cur = con.cursor()

print("Creating database tables...")

# Enable foreign keys
cur.execute('PRAGMA foreign_keys = ON;')

# Create signup table
cur.execute('''
CREATE TABLE IF NOT EXISTS signup (
    Customer_id INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    cell_number TEXT NOT NULL UNIQUE,
    residential_address TEXT NOT NULL,
    password TEXT NOT NULL
);
''')
print("✓ Created 'signup' table")

# Create queries table
cur.execute('''
CREATE TABLE IF NOT EXISTS queries (
    query_id INTEGER PRIMARY KEY AUTOINCREMENT,
    Customer_id INTEGER NOT NULL,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL,
    cell_number TEXT NOT NULL,
    problem_description TEXT NOT NULL,
    details TEXT NOT NULL,
    FOREIGN KEY (Customer_id) REFERENCES signup(Customer_id)
);
''')
print("✓ Created 'queries' table")

# Create timeseek table
cur.execute('''
CREATE TABLE IF NOT EXISTS timeseek (
    time TEXT PRIMARY KEY NOT NULL
);
''')
print("✓ Created 'timeseek' table")

# Create dayofmonth table
cur.execute('''
CREATE TABLE IF NOT EXISTS dayofmonth (
    day INTEGER PRIMARY KEY NOT NULL
);
''')
print("✓ Created 'dayofmonth' table")

# Create slot table
cur.execute('''
CREATE TABLE IF NOT EXISTS slot (
    slot_id INTEGER PRIMARY KEY AUTOINCREMENT,
    Customer_id INTEGER NOT NULL,
    day INTEGER NOT NULL,
    time TEXT NOT NULL,
    FOREIGN KEY (Customer_id) REFERENCES signup(Customer_id),
    FOREIGN KEY (day) REFERENCES dayofmonth(day),
    FOREIGN KEY (time) REFERENCES timeseek(time)
);
''')
print("✓ Created 'slot' table")

# Create tracklaundry table
cur.execute('''
CREATE TABLE IF NOT EXISTS tracklaundry (
    laundry_id INTEGER PRIMARY KEY AUTOINCREMENT,
    Customer_id INTEGER NOT NULL,
    FOREIGN KEY (Customer_id) REFERENCES signup(Customer_id)
);
''')
print("✓ Created 'tracklaundry' table")

# Insert sample users with HASHED passwords
print("\nInserting sample users...")
sample_users = [
    ('Tshepo Choene', 'Tshepochoene14@gmail.com', '0694034979', 'Pretoria', 'tshepo1224'),
    ('Thabang Matlou', 'Thabangmatlou32@gmail.com', '0694044979', 'Cape Town', 'thabang114'),
    ('Musa Mthombeni', 'Musamthombeni41@gmail.com', '0694054979', 'Pretoria', 'musa145'),
    ('Tshepang Masingiti', 'Tshepangmasingiti12@gmail.com', '0694064979', 'Joburg', 'tshepang1234'),
    ('Lebogang Leisa', 'Lebogangleisa24@gmail.com', '0694074979', 'Joburg', 'lebogang1445'),
    ('Lesego Matome', 'Lesegomatome11@gmail.com', '0694084979', 'Pretoria', 'lesego1344'),
    ('Lerato Moloi', 'Leratomoloi32@gmail.com', '0624094979', 'Cape Town', 'lerato1234!'),
    ('Tshego Shona', 'Tshegoshona47@gmail.com', '0623014979', 'Pretoria', 'tshego41!'),
    ('Monique Du plessis', 'Moniquedp12@gmail.com', '0623024979', 'Joburg', 'monique44!'),
    ('Lucas Vasquez', 'Lucasvasquez23@gmail.com', '0624044979', 'Cape Town', 'lucasvasq10!')
]

for user in sample_users:
    hashed_password = generate_password_hash(user[4])
    cur.execute('''
        INSERT INTO signup (full_name, email, cell_number, residential_address, password)
        VALUES (?, ?, ?, ?, ?)
    ''', (user[0], user[1], user[2], user[3], hashed_password))
    print(f"✓ Added user: {user[0]}")

# Insert sample time slots
print("\nInserting time slots...")
time_slots = ['08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00']
for time in time_slots:
    cur.execute('INSERT INTO timeseek (time) VALUES (?)', (time,))
print(f"✓ Added {len(time_slots)} time slots")

# Insert days of month (1-31)
print("\nInserting days of month...")
for day in range(1, 32):
    cur.execute('INSERT INTO dayofmonth (day) VALUES (?)', (day,))
print("✓ Added days 1-31")

# Commit all changes
con.commit()
con.close()

print("\n" + "="*50)
print("✅ DATABASE CREATED SUCCESSFULLY!")
print("="*50)
print("\nDatabase: signup1.db")
print("Tables created: signup, queries, timeseek, dayofmonth, slot, tracklaundry")
print(f"Sample users: {len(sample_users)}")
print("\n⚠️  NOTE: All passwords are now HASHED for security")
print("\nTest Login Credentials:")
print("  Email: Tshepochoene14@gmail.com")
print("  Password: tshepo1224")
print("\nYou can now run: python appli.py")